# FPGA-Racing-Game

Overview:
This is a racing game on FPGA. It is coded in Verilog. I used Nexys 4 DDR as my FPGA. 
The road is generated using C# code that I coded to output bitmap of the road.
The sound is a PWM. I sampled a sound clip at 8000 samples/second and then turned that into binary file. 
All of these are explained in the files themselfs. 

Components:
VGA monitor, speaker, USB keyboard


Video:
https://youtu.be/mqfI2xpCRDE


